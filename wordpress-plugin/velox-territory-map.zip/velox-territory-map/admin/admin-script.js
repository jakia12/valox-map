// Velox Territory Map Admin JavaScript
(function ($) {
  "use strict";

  $(document).ready(function () {
    console.log("Velox Territory Map Admin loaded");

    // Additional admin functionality can be added here
    // The main functionality is already in admin-page.php inline script
  });
})(jQuery);
